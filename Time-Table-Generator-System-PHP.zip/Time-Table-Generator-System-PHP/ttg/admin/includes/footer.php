 <div class="row">
                        <div class="col-lg-12">
                            <div class="footer">
                                <p>Time Table Generator</p>
                            </div>
                        </div>
                    </div>